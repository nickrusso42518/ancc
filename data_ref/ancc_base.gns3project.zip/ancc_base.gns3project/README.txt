Project: 'ancc_base' created on 2024-01-08
Author: Nick Russo <njrusmc@gmail.com>

Relates to: https://github.com/nickrusso42518/ancc